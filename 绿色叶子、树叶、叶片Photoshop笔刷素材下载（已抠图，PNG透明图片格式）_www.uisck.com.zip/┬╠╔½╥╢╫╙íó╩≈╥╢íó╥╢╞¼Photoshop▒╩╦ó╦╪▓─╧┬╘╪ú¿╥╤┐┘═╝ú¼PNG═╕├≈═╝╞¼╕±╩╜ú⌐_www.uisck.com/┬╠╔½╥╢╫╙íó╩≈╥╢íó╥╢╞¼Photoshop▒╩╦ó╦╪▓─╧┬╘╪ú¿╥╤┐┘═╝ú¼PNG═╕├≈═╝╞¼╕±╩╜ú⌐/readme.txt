Leaf Pack by Joannastar
=======================

Thank you for downloading my images! In this zip are 12 transparent .pngs of leaves.

They are licensed under the Creative Commons Attribution license version 2.5. This means, in summary, that

You are free:
* to Share -- to copy, distribute, display, and perform the work
* to Remix -- to make derivative works

Under the following conditions:
* Attribution. You must attribute the work in the manner specified by the author or licensor. 
* For any reuse or distribution, you must make clear to others the license terms of this work.
* Any of these conditions can be waived if you get permission from the copyright holder.

You must attribute me in the following way:
* On Deviantart, you must have a link to either my stock account, http://joannastar-stock.deviantart.com, or my main account, http://joannastar.deviantart.com in the description of the deviation.
* Elsewhere on the web, you may put a link to my deviantart account http://joannastar.deviantart.com or my website, http://spacegirl.me.uk on the page you use the graphic.
The full legal text of the licence is available here: http://creativecommons.org/licenses/by/2.5/legalcode

(The summary page is here: http://creativecommons.org/licenses/by/2.5/)


This is not a license requirement, but I would really appreciate seeing whatever you make with these images. Also I'd love it if you let me know what you think about these - let me know if they're useful, or if there's something I could do to make them better. I'm more likely to make future packs if I think these have been used :) You can either note me on deviantart, or email me.

Images � 2007 Joanna Gait (aka Joannastar)
Email: spacegirl81@gmail.com
http://spacegirl.me.uk
http://joannastar.deviantart.com
http://joannastar-stock.deviantart.com