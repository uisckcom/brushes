To "install" these to your SAI:

1) Copy the images from the "blotmap" folder
2) Go to C:\Program Files\ and find the PaintTool SAI folder
3) Inside the SAI folder, open up the "blotmap" folder
4) Paste the images
5) Do the same for the "elemap" folder
6) Start SAI and have fun.

These textures came pre-installed with my SAI, so I have no claim to them.