----------------------------------------------------------
----------------------------------------------------------


	+------------------------------------+
	|				     |
	|  Fylgjur's "Manga Lace" Brush Set  |
	|				     |
	+------------------------------------+

	http://fylgjur.deviantart.com/

----------------------------------------------------------
----------------------------------------------------------

 - Set of four brushes for use in CLIP STUDIO PAINT:
		- Fylgjur_Manga_Lace_1.sut
		- Fylgjur_Manga_Lace_2.sut
		- Fylgjur_Manga_Lace_3.sut
		- Fylgjur_Manga_Lace_4.sut

 - Please link back to my page if you use them! :)

----------------------------------------------------------


   INSTALL & USE:
   --------------

 1. Open CLIP STUDIO PAINT

 2. Select the "Decoration" brush Sub-Tool

 3. Access your computer's file explorer and open the
    folder that contains the lace brush [.sut] files

 4. Use the cursor to drag and drop the [.sut] files
    from the file explorer into the Decoration brush
    menu.

 5. Select the lace brushes and draw on your image.

 6. If the lace appears distorted, please increase brush
    stability and draw with a tablet stylus.


----------------------------------------------------------
----------------------------------------------------------