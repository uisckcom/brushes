http://darlingmionette.deviantart.com

You may use any of the brushes/textures etc in this file without giving me credit, 100% free. Have fun!  If you'd like to create your own custom brushes, feel free to check out my Custom Brush Tutorial here: http://fav.me/d2ohylt

Please don't repost my brushes or textures anywhere without my permission!

----------------------------------------------------------------------------------------------------

INSTRUCTIONS
------------
1. select all contents of this zip folder and drag them into your main SAI directory.

(If you don't know where your main SAI directory is, run a computer-wide search for "sai.exe" this file is located in your main SAI directory.

2. If your computer asks you if you want to merge your files, say YES.


3. In your SAI directory find these files:

brushform.conf
brushtex.conf
papertex.conf

Right click on each one and hit "OPEN WITH" and then choose "Notepad". When it opens, start a new line at the end and copy and paste the lines below into the .conf files:

(brushform.conf)
1,blotmap\Noise 1 bltmp.bmp
1,blotmap\Speckle 1 bltmp.bmp
1,blotmap\Spread 1 bltmp.bmp
2,elemap\Chalk.bmp
2,elemap\Fine Flat 2 em.bmp
2,elemap\Fine Flat 3 em.bmp
2,elemap\Fine Hollow 1 em.bmp
2,elemap\Fine Round 2 em.bmp
2,elemap\Grass 1 em.bmp
2,elemap\Middle Round 1 em.bmp
2,elemap\Rough Round 1 em.bmp

(brushtex.conf)
1,brushtex\Marble 2 pt.bmp
1,brushtex\Paper 1 pt.bmp
1,brushtex\Watercolor 1 pt.bmp
1,brushtex\Watercolor 2 pt.bmp

(papertex.conf)
1,papertex\Marble 1 pt.bmp
1,papertex\Marble 2 pt.bmp
1,papertex\Paper 1 pt.bmp
1,papertex\Watercolor 1 pt.bmp
1,papertex\Watercolor 2 pt.bmp
1,papertex\Watercolor 3 pt.bmp
1,papertex\Watercolor 4 pt.bmp

5. Save the .conf files and exit out of them.


CONGRATULATIONS, YOU HAVE SUCCESSFULLY INSTALLED YOUR NEW TEXTURES! - BUT YOU ARE NOT DONE!


5. Open up the "Mio's Brush Settings" folder (contained within this .zip).  Inisde you will find screenshots of all my brush settings.  To create these brushes, you need to right click any blank square in your brush menu to create a new brush, and then edit the settings to match those you see in the screenshot.  BRUSHES ARE NOT CREATED AUTOMATICALLY. YOU HAVE TO DO THIS MANUALLY.

----------------------------------------------------------------------------------------------------

IF YOU HAVE PROBLEMS WITH TEXTURES NOT SHOWING UP:

1. Close SAI.
2. Open your .conf files and delete the lines (above) from the end of the files.
3. Save and close the .conf files.
4. Reboot your computer.
5. Open your .conf files back up and re-add the lines above.
6. Start SAI.


All textures should show after this. BUT, SAI is notoriously finicky sometimes and it may take several tries.  If you have any further problems, feel free to message me on deviantART - I've seen every error possible, and I can probably help you fix yours. :3

<3 Mio